# Affiliate Link Shortener + Facebook Preview

Aplikasi Node.js sederhana untuk memperpendek link afiliasi dan menampilkan
preview foto (Open Graph) saat dibagikan di Facebook/WhatsApp/Twitter.

## Cara Menjalankan di Komputer (opsional, untuk coba-coba)
```bash
npm install
npm start
```
Buka `http://localhost:3000`

## Cara Deploy ke Internet (gratis)

Karena preview Facebook butuh server yang benar-benar online, pilih salah satu:

### Opsi 1: Railway (paling mudah)
1. Buat akun di https://railway.app
2. New Project → Deploy from GitHub repo (upload folder ini ke GitHub dulu)
3. Railway otomatis deteksi Node.js dan jalankan `npm start`
4. Setelah deploy, buka Settings → Networking → Generate Domain
5. Tambahkan environment variable: `BASE_URL` = domain yang didapat (contoh: `https://xxxx.up.railway.app`)
6. Redeploy

### Opsi 2: Render
1. Buat akun di https://render.com
2. New → Web Service → hubungkan repo GitHub kamu
3. Build command: `npm install`, Start command: `npm start`
4. Tambahkan environment variable `BASE_URL` sesuai domain yang diberikan Render

### Opsi 3: VPS sendiri (misal DigitalOcean/Niagahoster)
1. Upload folder ini ke server
2. `npm install`
3. Jalankan dengan PM2: `pm2 start server.js`
4. Pasang domain + SSL (Nginx + certbot)
5. Set `BASE_URL` ke domain kamu

## Cara Pakai
1. Buka halaman utama (`/`)
2. Isi URL afiliasi tujuan, judul, deskripsi, dan **URL foto** untuk preview
3. Klik "Buat Link Pendek"
4. Bagikan link pendek yang muncul (contoh: `https://domainmu.com/promo-sepatu`) ke Facebook

## Catatan Penting
- Sekarang kamu bisa **upload foto langsung** dari halaman admin (tombol
  upload di bawah "URL Afiliasi Tujuan") — tidak perlu lagi ke Imgur. Foto
  otomatis tersimpan di folder `public/uploads/` dan link-nya otomatis
  terisi. Kolom URL foto tetap bisa dipakai manual kalau kamu sudah punya
  link gambar dari tempat lain.
- **Fitur kolase:** kalau kamu pilih lebih dari 1 foto sekaligus (maksimal 4),
  server otomatis menggabungkannya jadi satu gambar grid berukuran
  1200x630px (rasio ideal Facebook) dan memakainya sebagai foto preview.
  Cocok untuk produk dengan beberapa varian warna/model dalam satu link.
- ⚠️ **Penting soal hosting gratis (Railway/Render):** folder `public/uploads/`
  ini biasanya **tidak permanen** di hosting gratis — kalau server
  redeploy/restart, foto yang sudah diupload bisa hilang. Untuk pemakaian
  serius jangka panjang, sebaiknya foto tetap disimpan di layanan eksternal
  seperti Imgur/Cloudinary, atau upgrade ke hosting berbayar dengan disk
  permanen.
- Ukuran foto ideal untuk Facebook: rasio landscape 1200x630px (bukan foto
  tegak/portrait), supaya tidak ke-crop aneh saat jadi preview link.
- Maksimal ukuran tiap file upload: 5MB. Format yang didukung: JPG, PNG, WEBP, GIF.
- Setelah share pertama kali, Facebook menyimpan cache preview. Kalau kamu
  ganti foto/judul link yang sama, gunakan
  [Facebook Sharing Debugger](https://developers.facebook.com/tools/debug/)
  untuk refresh cache-nya.
- Data link disimpan di file `data/links.json`. Untuk skala besar/produksi,
  sebaiknya diganti ke database (misalnya PostgreSQL atau SQLite).
